module.exports = {
  url: "mongodb+srv://Jesse:JesseAss@jesse.mhs3o.mongodb.net/?retryWrites=true&w=majority"
};